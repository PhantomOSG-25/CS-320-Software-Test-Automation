package Test;


import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;


import java.util.Calendar;
import java.util.Date;


import Appointment.Appointment;

class AppointmentTest {
	
	@Test
	void testApptConstruct() {
		Calendar c = Calendar.getInstance();
		c.set(2025, 4, 3, 3, 30);
			Date date = c.getTime();
			
			// Test Id Length
			Assertions.assertThrows(IllegalArgumentException.class, () ->{
				new Appointment("12345678901", date, "Id invalid too long");
			});
			 
			// Id empty
			Assertions.assertThrows(IllegalArgumentException.class,() ->{
				new Appointment(null, date, "Id Invalid");
			});
			
			// Date Empty
			Assertions.assertThrows(IllegalArgumentException.class, () ->{
				new Appointment("1234567890", null, "Date Invalid");
			});
			
			//Invalid Date Before Today
			date.setTime(0);
			Assertions.assertThrows(IllegalArgumentException.class,() ->{
				new Appointment("1234567890", date, "Invalid Date");
			});
			
			// Description Empty
			Assertions.assertThrows(IllegalArgumentException.class, () ->{
				new Appointment("1234567890", date, null);
			});

			// Invalid Description Too Long
			Assertions.assertThrows(IllegalArgumentException.class, () ->{
				new Appointment("1234567890", date, "Description is invalid" + "Due the fact that it only allows up to fifty characters");
			});
			
			//Check if Parameters are correct and being followed
			Date newDate = c.getTime();
			Appointment appt = new Appointment("1234567890", newDate, "Appt Description");
			assertTrue(appt.getapptId().equals("1234567890"));
			assertTrue(appt.getapptDate().equals(newDate));
			assertTrue(appt.getapptdDesc().equals("Appointment Description"));
	}
		
	@Test
	void testSetters() {
		Calendar c = Calendar.getInstance();
		c.set(2022, 10, 5, 9, 15);
		Date date = c.getTime();
		Date newDate = c.getTime();
		Date badDate = new Date();
		badDate.setTime(10000);
		
		// Create base
		Appointment appt = new Appointment("1234567890", date, "Appt Description");
		
		// New Description Set
		appt.SetapptDesc("Appointment Description");
		
		// Empty Description Error
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			appt.SetapptDesc(null);
		});
		
		// lDescription too Long Error
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			appt.SetapptDesc("Description is not valid due to having used more than fifty characters");
		});
		// Check description changes
		assertTrue(appt.getapptdDesc().equals("Appointment Description"));
		
		// Invalid date prior to tiday
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			appt.SetApptDate(badDate);
		});
		// Date is Empty
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			appt.SetApptDate(null);
		});
		
		// Checking for Correct Date
		appt.SetApptDate(newDate);
		// Check Date Changes
		assertTrue(appt.getapptDate().equals(newDate));
		
	}
	
}	
