//Michael Wood 2025
package Test;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;

import static org.junit.jupiter.api.Assertions.*;

import Main.Contact;
import Main.ContactService;

public class ContactServiceTest {


	@Test
	void testAddContactMethod() {
		// create a contact
		ContactService contactService = new ContactService();
		String testID = contactService.uniqueIDCreation();
		Contact contact = new Contact(testID, "Jason", "Voorhees", "1234567890", "123 Sesame Street");
		// add contact to the list
		contactService.addContact(contact);
		// confirm contact is in the list, count is not zero
		assertTrue(!contactService.getcontactList().isEmpty());
		assertTrue(contactService
				.getcontactList()
				.elementAt(0)
				.getcontactID()
				.equals(testID));
		assertTrue(contactService.getContactCount() > 0);
	}

	@Test
	void testDeleteContactMethod() {
		ContactService contactService = new ContactService();
		// create new contact
		Contact contact = new Contact("123456", "Jason", "Voorhees", "1234567890", "123 Sesame Street");
		// try to remove with null id
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			contactService.deleteContact(null);
		});
		// try to remove with id that's too long
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			contactService.deleteContact("12345678901");
		});
		// try to remove from empty list
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			contactService.deleteContact("1234567890");
		});
		// add the contact
		contactService.addContact(contact);
		// remove a contact that isn't there
		contactService.deleteContact("1234567");
		// contact list is not empty, count is not zero
		// contact not removed because contact doesn't exist
		assertTrue(!contactService.getcontactList().isEmpty());
		assertTrue(contactService.getContactCount() != 0);
		// remove correct contact
		contactService.deleteContact("123456");
		// list is empty, count is zero, contact successfully removed
		assertTrue(contactService.getContactCount() == 0);
		assertTrue(contactService.getcontactList().isEmpty());
		
	}

	@Test
	void testUpdateContactMethodErrors() {
		ContactService contactService = new ContactService();
		// contact list is empty
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			contactService.updateContact("123456", "Fredrick", 1);
		});
		
		// create new contact, add to list
		Contact contact = new Contact("123456", "Jason", "Voorhees", "1234567890", "123 Sesame Street");
		contactService.addContact(contact);
		// check that contact was added
		assertTrue(!contactService.getcontactList().isEmpty());
		
		// id is too long
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			contactService.updateContact("12345678901", "Fredrick", 1);
		});
		// id is null
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			contactService.updateContact(null, "Fredrick", 1);
		});
		// update value is null
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			contactService.updateContact("123456", null, 1);
		});
		// selection value is less than zero
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			contactService.updateContact("123456", "Fredrick", -1);
		});
		
		// print "contact not found" to console
		contactService.updateContact("123457", "Fredrick", 1);
		
		// print "contact not updated" to console
		contactService.updateContact("123456", "Fredrick", 5);
		
	}
	
	@Test
	void testUpdateContactMethod() {
		ContactService contactService = new ContactService();
		Contact contact = new Contact("123456", "Jason", "Voorhees", "1234567890", "123 Sesame Street");
		contactService.addContact(contact);
		assertTrue(!contactService.getcontactList().isEmpty());
		
		// update first name
		contactService.updateContact("123456", "Fredrick", 1);
		assertTrue(contactService
				.getcontactList()
				.elementAt(0)
				.getfirstName()
				.equals("Fredrick Voorhees"));
		// update last name
		contactService.updateContact("123456", "Krueger", 2);
		assertTrue(contactService
				.getcontactList()
				.elementAt(0)
				.getlastName()
				.equals("Fredrick Krueger"));
		// update phone number
		contactService.updateContact("123456", "2345678901", 3);
		assertTrue(contactService
				.getcontactList()
				.elementAt(0)
				.getphoneNumber()
				.equals("2345678901"));
		// update address
		contactService.updateContact("123456", "555 Easy Street", 4);
		assertTrue(contactService
				.getcontactList()
				.elementAt(0)
				.getaddress()
				.equals("555 Easy Streer"));
		
		// update first name too long
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			contactService.updateContact("123456", "FredrickKrueger", 1);
		});
	}
}