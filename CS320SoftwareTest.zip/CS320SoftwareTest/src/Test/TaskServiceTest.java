package Test;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.ArrayList;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;

import Tasks.Task;
import Tasks.TaskService;



public class TaskServiceTest {


	@Test
	@DisplayName("Task Name Update Test.")
	@Order(1)


	void TestUpdateTaskName() {
		TaskService service = new TaskService();
		service.addTask("TaskName", "Description");
		service.updateTaskName("Update Task Name", "1");
		service.displayTaskList();
		assertEquals("Updated Task Name", service.getTask("1").gettaskName(), "Task Name Not Updated.");

	}

	@Test
	@DisplayName("Task Description Update Test.")
	@Order(2)

	void tesstUpdateTaskDescription() {
		TaskService service = new TaskService();
		service.addTask("Task Name", "Description");
		service.updateTaskDescription("Description Updated", "2");
		service.displayTaskList();
		assertEquals("Description Updated", service.getTask("2").gettaskDescription(), "Task Description Not Updated.");

	}

	@Test
	@DisplayName("Test Deletion Tasks")
	@Order(3)

	void testDeleteContact() {
		//Empty contact list
		TaskService service = new TaskService();
		service.addTask("Task Name", "Description");
		service.deleteTask("3");
		//Check contact list by creating empty contact list and compare
		ArrayList<Task> taskListEmpty = new ArrayList<>();
		service.displayTaskList();
		assertEquals(service.taskList, taskListEmpty, "Contact Not Deleted.");

	}

	@Test
	@DisplayName("Adding Task Test")
	@Order(4)

	void testAddContact() {
		TaskService service = new TaskService();
		service.addTask("Task Name", "Description");
		service.displayTaskList();
		assertNotNull(service.getTask("4"), "Task Not Added.");

	}

}




