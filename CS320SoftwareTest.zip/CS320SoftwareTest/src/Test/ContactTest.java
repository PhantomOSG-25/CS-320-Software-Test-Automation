
package Test;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;


import Main.Contact;

class ContactTest {


	@Test
	void testContactNullStatements() {
		Assertions.assertThrows(IllegalArgumentException.class,() ->{
			new Contact(null, null, null, null, null);
			});
		}
	
	@Test
	//getters
	void testContactGetters() {
		Contact contact = new Contact("123456", "Jason", "Voorhees", "1234567890", "123 Sesame Street");
		assertTrue(contact.getfirstName().equals("Jason"));
		assertTrue(contact.getlastName().equals("Voorhees"));
		assertTrue(contact.getphoneNumber().equals(1234567890));
		assertTrue(contact.getaddress().equals("123 Sesame Street"));
		assertTrue(contact.getcontactID().equals("123456"));
	}
	
	@Test
	//test first and last name
	void testfirstLastName() {
		Contact contact = new Contact("123456", "Jason", "Voorhees", "1234567890", "123 Sesame Street");
		contact.setfirstName("Fredrick");
		contact.setlastName("Krueger");
		contact.getfirstName().equals("Fredrick");
		contact.setlastName("Krueger");
		assertTrue(contact.getfirstName().equals("Fredrick"));
		assertTrue(contact.getlastName().equals("Krueger"));
	}
	
	@Test
	//test phone number and address
	void testphoneNumberAddress() {
		Contact contact = new Contact("123456", "Jason", "Voorhees", "1234567890", "123 Sesame Street");
		contact.setphoneNumber("1234567890");
		contact.setaddress("123 Sesame Street");
		assertTrue(contact.getphoneNumber().equals("1234567890"));
		assertTrue(contact.getaddress().equals("123 Sesame Street"));
	}
	
	@Test
	//test null attributes
	void testNulkAttributes() {
		Contact contact = new Contact("123456", "Jasoin", "Voorhees", "1234567890", "123 Sesame Street");
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contact.setfirstName(null);
		});
		
		Assertions.assertThrows(IllegalArgumentException.class,() -> {
			contact.setlastName(null);
		});
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contact.setaddress(null);
		});
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contact.setphoneNumber(null);
		});
	}
		
}



















