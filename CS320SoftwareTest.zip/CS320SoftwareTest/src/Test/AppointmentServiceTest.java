package Test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Calendar;
import java.util.Date;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import Appointment.Appointment;



class AppointmentServiceTest {

	@Test
	void testApptConstructor() {
		Calendar c = Calendar.getInstance();
		c.set(2022, 10, 5, 9, 15);
		Date date = c.getTime();
		
		
		//Date date = new Date(2022, 1, 10);
		System.out.println("Date set to " + date);
		
		
		
		//id too long
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			new Appointment("12345678901", date, "Appointment Description");
		});
		//id null
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			new Appointment(null, date , "Appointment Description");
		});
		//description too long
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			new Appointment("1234567890", date , "Description too long");
		});
		//description null
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			new Appointment("1234567890", date , null);
		});
		//date null
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			new Appointment("1234567890", null , "Appointment Description");
		});
		//date before today
		
		date.setTime(0);
		System.out.println("Date set to " + date);
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			new Appointment("1234567890", date , "Appointment Description");
		});
		
		//everything correct
		Date newDate = c.getTime();
		Appointment appt = new Appointment("1234567890", newDate, "Appointment Description");
		assertTrue(appt.getapptId().equals("1234567890"));
		assertTrue(appt.getapptDate().equals(newDate));
		assertTrue(appt.getapptdDesc().equals("Appointment Description"));
		
	}
	
	@Test
	void testSetters() {
		Calendar c = Calendar.getInstance();
		c.set(2022, 10, 5, 9, 15);
		Date date = c.getTime();
		Date newDate = c.getTime();
		Date badDate = new Date();
		badDate.setTime(10000);
		
		// make object
		Appointment appt = new Appointment("1234567890", date, "Appointment Description");
		
		// set new description
		appt.SetapptDesc("Appointment description");
		// null description error
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			appt.SetapptDesc(null);
		});
		// long description error
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			appt.SetapptDesc("Description too long");
		});
		// check that description is changed
		assertTrue(appt.getapptdDesc().equals("Appointment description"));
		
		// date is before today
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			appt.SetApptDate(badDate);
		});
		// date is null
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			appt.SetApptDate(null);
		});
		
		// date is appropriate
		appt.SetApptDate(newDate);
		// check that date changed
		assertTrue(appt.getapptDate().equals(newDate));
		
	}

}