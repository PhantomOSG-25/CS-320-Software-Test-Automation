package Test;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import Tasks.Task;



public class TaskTest {

	@Test

	//constructors
	void TaskConstructor() {
		// ID too Long
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			new Task("1234567890", "TaskName", "TaskDescription");
		});

		//Name too Long
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			new Task("1234567890", "TaskNameABCDEFGHIKLM", "TaskCescription");
		});

		//Description too Long
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			new Task("1234567890", "Task Name", "TaskDescriptionTaskDescriptionTaskDescription" + "TaskDescriptionTaskDescriptionTaskDescription");
		});

		//ID null

		Assertions.assertThrows(IllegalArgumentException.class,()->{
			new Task(null, "TaskName", "TaskDescription");
		});

		//Name null

		Assertions.assertThrows(IllegalArgumentException.class,()->{
			new Task("1234567890", null, "TaskDescritpion");
		});


		//Description null

		Assertions.assertThrows(IllegalArgumentException.class,()-> {
			new Task("1234567890", "Task Name", null);
		});
	}

	// Getters

	@Test

	void testTaskGetters() {
		Task task = new Task("1234567890", "Task Name", "Task Description");
		assertTrue(task.gettaskID().equals("1234567890"));
		assertTrue(task.gettaskName().equals("Task Name"));
		assertTrue(task.gettaskDescription().equals("Task Description"));

	}

	@Test

	void testTaskSetters() {
		Task task = new Task("123456789", "Task Name", "Task Description");
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			task.SettaskName(null);
		});

		Assertions.assertThrows(IllegalArgumentException.class,()->{
			task.SettaskName("Name is too Long 20 Character Max.");
		});

		Assertions.assertThrows(IllegalArgumentException.class,()->{
			task.SettaskDescription(null);
		});

		Assertions.assertThrows(IllegalArgumentException.class,()-> {
			task.SettaskDescription("Description too Long 50 Character Max.");
		});

		task.SettaskName("New Name");
		task.SettaskDescription("New Description");
		assertTrue(task.gettaskName().equals("New Name"));
		assertTrue(task.gettaskDescription().equals("New Desctription"));

		}
}






